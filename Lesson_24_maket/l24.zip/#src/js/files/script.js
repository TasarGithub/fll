
let langHeaderCurrent = document.querySelector('.lang-header__current');
if (langHeaderCurrent) {
	let go = true;
	langHeaderCurrent.addEventListener("click", function (e) {
		if (go) {
			go = false;
			langHeaderCurrent.classList.toggle('_active');
			_slideToggle(langHeaderCurrent.nextElementSibling);

			setTimeout(function () {
				go = true;
			}, 500);
		}
	});
	document.addEventListener("click", function (e) {
		if (!e.target.classList.contains('lang-header__current') && !e.target.classList.contains('lang-header__items')) {
			langHeaderCurrent.classList.remove('_active');
			_slideUp(langHeaderCurrent.nextElementSibling);
		}
	});
}